namespace TrilhaApiDesafio.Models
{
    public enum EnumStatusTarefa
    {
        Pendente,
        Finalizado
    }
}